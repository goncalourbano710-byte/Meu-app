"use client"

import { Lock } from "lucide-react"

interface Props {
  featureName: string
  description: string
  onUpgrade: () => void
}

export default function PaywallGate({ featureName, description, onUpgrade }: Props) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-[#6C63FF]/30 bg-gradient-to-br from-[#6C63FF]/8 to-[#FF6584]/8 p-4">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-[#6C63FF]/15 flex items-center justify-center flex-shrink-0">
          <Lock className="w-5 h-5 text-[#6C63FF]" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold text-foreground">{featureName}</p>
          <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{description}</p>
          <button
            onClick={onUpgrade}
            className="mt-2.5 text-xs font-bold text-white bg-gradient-to-r from-[#6C63FF] to-[#9C8DFF] px-3 py-1.5 rounded-lg active:scale-95 transition-all"
          >
            Desbloquear com Premium
          </button>
        </div>
      </div>
      {/* Decorative blur */}
      <div
        className="absolute -top-4 -right-4 w-16 h-16 rounded-full blur-2xl opacity-30"
        style={{ background: "#6C63FF" }}
        aria-hidden
      />
    </div>
  )
}
