"use client"

import { useState, useEffect } from "react"
import {
  X, Star, Check, Zap, Crown, ArrowRight, Sparkles, Shield,
  ChevronDown, ChevronLeft, CreditCard, QrCode, FileText,
  Lock, Infinity, Gift, Rocket, Brain, BarChart3, CloudUpload,
  Download, Target, CheckCircle2,
} from "lucide-react"
import {
  PLANS, PREMIUM_FEATURES, Plan, PlanId,
  loadPremium, activatePlan, isPremium, getPlanLabel, getExpiryLabel, PremiumState,
} from "@/lib/premium"

interface Props {
  onClose: () => void
  onActivate: (state: PremiumState) => void
  initialPremium?: PremiumState
}

type PayMethod = "card" | "pix" | "boleto"

const FEATURE_COMPARE = [
  { label: "Atividades por dia",      free: "5",          premium: "Ilimitadas" },
  { label: "Sugestoes de IA",         free: "3/semana",   premium: "Ilimitadas" },
  { label: "Relatorios detalhados",   free: false,        premium: true },
  { label: "Exportar PDF / Excel",    free: false,        premium: true },
  { label: "Backup na nuvem",         free: false,        premium: true },
  { label: "Metas e desafios",        free: false,        premium: true },
  { label: "Tecnica Pomodoro",        free: false,        premium: true },
  { label: "Temas exclusivos",        free: false,        premium: true },
  { label: "Suporte prioritario",     free: false,        premium: true },
]

const BENEFIT_ICONS = [Rocket, Brain, BarChart3, CloudUpload, Download, Target]

const PAY_METHODS: { id: PayMethod; label: string; subtitle: string; Icon: typeof CreditCard }[] = [
  { id: "card",   label: "Cartao de credito",  subtitle: "Visa, Mastercard, Elo",  Icon: CreditCard },
  { id: "pix",    label: "PIX",                subtitle: "Aprovacao imediata",     Icon: QrCode },
  { id: "boleto", label: "Boleto bancario",     subtitle: "Vencimento em 3 dias",  Icon: FileText },
]

const FAQS = [
  {
    q: "Posso cancelar a qualquer momento?",
    a: "Sim! Voce pode cancelar sua assinatura a qualquer momento sem cobranças adicionais. O acesso permanece ativo ate o final do periodo pago.",
  },
  {
    q: "O plano Vitalicio inclui atualizacoes futuras?",
    a: "Sim, o plano Vitalicio garante acesso a todas as funcionalidades atuais e futuras do RotineAI sem custo adicional.",
  },
  {
    q: "Como funciona o pagamento?",
    a: "Aceitamos cartao de credito, PIX e boleto bancario. O pagamento e processado com segurança via gateway criptografado.",
  },
  {
    q: "Existe garantia de reembolso?",
    a: "Oferecemos 7 dias de garantia total. Se nao estiver satisfeito, devolvemos 100% do valor pago, sem perguntas.",
  },
]

export default function PremiumModal({ onClose, onActivate, initialPremium }: Props) {
  const [selectedPlan, setSelectedPlan] = useState<PlanId>("annual")
  const [premiumState, setPremiumState] = useState<PremiumState>(initialPremium ?? loadPremium())
  const [step, setStep] = useState<"plans" | "checkout" | "success">("plans")
  const [payMethod, setPayMethod] = useState<PayMethod>("card")
  const [processing, setProcessing] = useState(false)
  const [openFaq, setOpenFaq] = useState<number | null>(null)
  const [showCompare, setShowCompare] = useState(false)
  const [cardNumber, setCardNumber] = useState("")
  const [cardExpiry, setCardExpiry] = useState("")
  const [cardCvv, setCardCvv] = useState("")
  const [cardName, setCardName] = useState("")
  const [mounted, setMounted] = useState(false)
  const [successCount, setSuccessCount] = useState(0)

  useEffect(() => { setMounted(true) }, [])

  const alreadyPremium = isPremium(premiumState)
  const activePlan = PLANS.find((p) => p.id === selectedPlan)!

  const formatCard = (v: string) =>
    v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim()
  const formatExpiry = (v: string) => {
    const d = v.replace(/\D/g, "").slice(0, 4)
    return d.length >= 2 ? d.slice(0, 2) + "/" + d.slice(2) : d
  }

  const canPay =
    payMethod !== "card" ||
    (cardNumber.replace(/\s/g, "").length === 16 &&
      cardExpiry.length === 5 &&
      cardCvv.length >= 3 &&
      cardName.trim().length > 3)

  const handleSubscribe = async () => {
    setProcessing(true)
    await new Promise((r) => setTimeout(r, 2200))
    const newState = activatePlan(selectedPlan)
    setPremiumState(newState)
    setProcessing(false)
    setStep("success")
    onActivate(newState)
    // animate feature count
    let i = 0
    const t = setInterval(() => {
      i++
      setSuccessCount(i)
      if (i >= activePlan.features.length) clearInterval(t)
    }, 200)
  }

  if (!mounted) return null

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden
      />

      {/* Sheet */}
      <div className="relative w-full max-w-md rounded-t-3xl overflow-hidden animate-slide-up flex flex-col"
        style={{
          background: "var(--color-card)",
          maxHeight: "96vh",
          boxShadow: "0 -8px 60px rgba(108,99,255,0.25)",
        }}
      >
        {/* Drag handle */}
        <div className="flex justify-center pt-3 pb-1 flex-shrink-0">
          <div className="w-10 h-1 rounded-full bg-border" />
        </div>

        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-muted flex items-center justify-center z-20 active:scale-90 transition-all"
          aria-label="Fechar"
        >
          <X className="w-4 h-4 text-muted-foreground" />
        </button>

        {/* ================================================================
            STEP: PLANS
        ================================================================ */}
        {step === "plans" && (
          <div className="overflow-y-auto flex-1">

            {/* --- Hero gradient banner --- */}
            <div
              className="relative px-5 pt-4 pb-8 text-center overflow-hidden"
              style={{
                background: "linear-gradient(160deg, #6C63FF 0%, #9C8DFF 50%, #FF6584 100%)",
              }}
            >
              {/* Decorative blobs */}
              <div className="absolute top-0 left-0 w-40 h-40 rounded-full bg-white/10 -translate-x-16 -translate-y-16" aria-hidden />
              <div className="absolute bottom-0 right-0 w-32 h-32 rounded-full bg-white/10 translate-x-12 translate-y-12" aria-hidden />

              {alreadyPremium ? (
                <>
                  <div className="relative inline-flex w-16 h-16 rounded-2xl bg-white/20 items-center justify-center mx-auto mb-3 shadow-xl">
                    <Crown className="w-9 h-9 text-white" />
                  </div>
                  <h2 className="text-xl font-bold text-white mb-1">Voce ja e Premium!</h2>
                  <p className="text-sm text-white/80">{getPlanLabel(premiumState.plan)}</p>
                  <p className="text-xs text-white/60 mt-1">{getExpiryLabel(premiumState)}</p>
                </>
              ) : (
                <>
                  <div className="relative inline-block mb-3">
                    <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center mx-auto shadow-xl">
                      <Crown className="w-9 h-9 text-white" />
                    </div>
                    <div className="absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full bg-[#FFB347] flex items-center justify-center shadow-lg">
                      <Star className="w-3.5 h-3.5 text-white fill-white" />
                    </div>
                  </div>
                  <h2 className="text-[22px] font-bold text-white mb-1 text-balance">
                    Desbloqueie o RotineAI Premium
                  </h2>
                  <p className="text-sm text-white/80 leading-relaxed text-pretty">
                    IA avancada, rotinas ilimitadas, relatorios completos e muito mais.
                  </p>

                  {/* Social proof */}
                  <div className="flex items-center justify-center gap-3 mt-3">
                    <div className="flex -space-x-2">
                      {["#6C63FF","#FF6584","#43D787","#FFB347"].map((c, i) => (
                        <div key={i} className="w-6 h-6 rounded-full border-2 border-white/60 flex-shrink-0"
                          style={{ background: c }} />
                      ))}
                    </div>
                    <p className="text-[11px] text-white/70 font-medium">
                      +2.400 usuarios ja assinaram
                    </p>
                  </div>
                </>
              )}
            </div>

            {/* ---- Already premium: feature list + close ---- */}
            {alreadyPremium && (
              <div className="px-5 py-5 space-y-2.5">
                {PREMIUM_FEATURES.map((f, i) => {
                  const Icon = BENEFIT_ICONS[i]
                  return (
                    <div key={i} className="flex items-center gap-3 bg-muted/60 rounded-2xl p-3.5">
                      <div className="w-10 h-10 rounded-xl bg-[#6C63FF]/15 flex items-center justify-center flex-shrink-0">
                        <Icon className="w-5 h-5 text-[#6C63FF]" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-foreground">{f.title}</p>
                        <p className="text-xs text-muted-foreground">{f.desc}</p>
                      </div>
                      <CheckCircle2 className="w-5 h-5 text-[#43D787] flex-shrink-0" />
                    </div>
                  )
                })}
                <button
                  onClick={onClose}
                  className="w-full mt-4 h-13 rounded-2xl text-white font-bold text-sm"
                  style={{
                    background: "linear-gradient(135deg, #6C63FF, #9C8DFF)",
                    boxShadow: "0 6px 24px rgba(108,99,255,0.35)",
                  }}
                >
                  Continuar usando Premium
                </button>
              </div>
            )}

            {/* ---- Not premium: plans, compare, CTA ---- */}
            {!alreadyPremium && (
              <>
                {/* Benefits grid */}
                <div className="px-5 pt-5 pb-3 grid grid-cols-2 gap-2.5">
                  {PREMIUM_FEATURES.map((f, i) => {
                    const Icon = BENEFIT_ICONS[i]
                    return (
                      <div key={i} className="bg-muted/60 rounded-2xl p-3.5 flex flex-col gap-2">
                        <div className="w-9 h-9 rounded-xl bg-[#6C63FF]/15 flex items-center justify-center">
                          <Icon className="w-4.5 h-4.5 text-[#6C63FF]" />
                        </div>
                        <p className="text-xs font-bold text-foreground leading-tight">{f.title}</p>
                        <p className="text-[10px] text-muted-foreground leading-tight">{f.desc}</p>
                      </div>
                    )
                  })}
                </div>

                {/* Compare table toggle */}
                <div className="px-5 pb-3">
                  <button
                    onClick={() => setShowCompare(!showCompare)}
                    className="w-full flex items-center justify-between p-3.5 bg-muted/50 rounded-2xl text-sm font-semibold text-foreground active:scale-98 transition-all"
                  >
                    <span className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-[#6C63FF]" />
                      Comparar planos
                    </span>
                    <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${showCompare ? "rotate-180" : ""}`} />
                  </button>

                  {showCompare && (
                    <div className="mt-2 rounded-2xl border border-border overflow-hidden animate-slide-in">
                      {/* Header */}
                      <div className="grid grid-cols-3 bg-muted/80">
                        <div className="p-2.5 text-[10px] font-bold text-muted-foreground uppercase tracking-wide">Recurso</div>
                        <div className="p-2.5 text-[10px] font-bold text-muted-foreground uppercase tracking-wide text-center border-l border-border">Gratis</div>
                        <div className="p-2.5 text-[10px] font-bold text-[#6C63FF] uppercase tracking-wide text-center border-l border-border flex items-center justify-center gap-1">
                          <Crown className="w-3 h-3" /> Premium
                        </div>
                      </div>
                      {FEATURE_COMPARE.map((row, i) => (
                        <div key={i} className={`grid grid-cols-3 border-t border-border ${i % 2 === 0 ? "" : "bg-muted/30"}`}>
                          <div className="p-2.5 text-[11px] text-foreground font-medium">{row.label}</div>
                          <div className="p-2.5 flex items-center justify-center border-l border-border">
                            {typeof row.free === "boolean" ? (
                              row.free
                                ? <Check className="w-3.5 h-3.5 text-[#43D787]" />
                                : <X className="w-3.5 h-3.5 text-muted-foreground/50" />
                            ) : (
                              <span className="text-[10px] text-muted-foreground">{row.free}</span>
                            )}
                          </div>
                          <div className="p-2.5 flex items-center justify-center border-l border-[#6C63FF]/20 bg-[#6C63FF]/5">
                            {typeof row.premium === "boolean" ? (
                              row.premium
                                ? <CheckCircle2 className="w-4 h-4 text-[#6C63FF]" />
                                : <X className="w-3.5 h-3.5 text-muted-foreground/50" />
                            ) : (
                              <span className="text-[10px] font-bold text-[#6C63FF]">{row.premium}</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Plan cards */}
                <div className="px-5 pb-4">
                  <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3">
                    Escolha seu plano
                  </p>
                  <div className="space-y-3">
                    {PLANS.map((plan) => (
                      <PlanCard
                        key={plan.id}
                        plan={plan}
                        selected={selectedPlan === plan.id}
                        onSelect={() => setSelectedPlan(plan.id)}
                      />
                    ))}
                  </div>
                </div>

                {/* Guarantee badge */}
                <div className="mx-5 mb-4 bg-[#43D787]/10 border border-[#43D787]/25 rounded-2xl p-3.5 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#43D787]/20 flex items-center justify-center flex-shrink-0">
                    <Shield className="w-5 h-5 text-[#43D787]" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-[#43D787]">Garantia de 7 dias sem risco</p>
                    <p className="text-[10px] text-muted-foreground leading-relaxed">
                      Nao gostou? Devolvemos 100% do seu dinheiro, sem perguntas.
                    </p>
                  </div>
                </div>

                {/* Primary CTA */}
                <div className="px-5 pb-5">
                  <button
                    onClick={() => setStep("checkout")}
                    className="w-full h-14 rounded-2xl text-white font-bold text-base flex items-center justify-center gap-2.5 active:scale-95 transition-all"
                    style={{
                      background: "linear-gradient(135deg, #6C63FF 0%, #9C8DFF 100%)",
                      boxShadow: "0 8px 32px rgba(108,99,255,0.4)",
                    }}
                  >
                    <Crown className="w-5 h-5" />
                    Assinar {activePlan.name}
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <p className="text-center text-[11px] text-muted-foreground mt-2">
                    {activePlan.id === "annual"
                      ? "R$ 94,90/ano · equivale a R$ 7,90/mes"
                      : `${activePlan.price} ${activePlan.priceNote}`}{" "}
                    · Cancele quando quiser
                  </p>
                </div>

                {/* FAQ */}
                <div className="px-5 pb-8">
                  <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3">
                    Perguntas frequentes
                  </p>
                  <div className="space-y-2">
                    {FAQS.map((faq, i) => (
                      <div key={i} className="bg-muted/50 rounded-2xl overflow-hidden">
                        <button
                          onClick={() => setOpenFaq(openFaq === i ? null : i)}
                          className="w-full flex items-center justify-between px-4 py-3.5 text-left gap-3"
                        >
                          <span className="text-xs font-semibold text-foreground">{faq.q}</span>
                          <ChevronDown
                            className={`w-4 h-4 text-muted-foreground flex-shrink-0 transition-transform ${openFaq === i ? "rotate-180" : ""}`}
                          />
                        </button>
                        {openFaq === i && (
                          <div className="px-4 pb-4 animate-slide-in">
                            <p className="text-xs text-muted-foreground leading-relaxed">{faq.a}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* ================================================================
            STEP: CHECKOUT
        ================================================================ */}
        {step === "checkout" && (
          <div className="overflow-y-auto flex-1 px-5 pb-8">
            {/* Back */}
            <button
              onClick={() => setStep("plans")}
              className="flex items-center gap-1.5 text-xs font-semibold text-primary mt-3 mb-5 active:opacity-70"
            >
              <ChevronLeft className="w-4 h-4" />
              Voltar aos planos
            </button>

            {/* Header */}
            <div className="flex items-center gap-3 mb-5">
              <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: "linear-gradient(135deg, #6C63FF, #9C8DFF)" }}>
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-base font-bold text-foreground">Finalizar assinatura</h2>
                <p className="text-xs text-muted-foreground">Revise e confirme seu pedido</p>
              </div>
            </div>

            {/* Order summary */}
            <div className="rounded-2xl border border-border overflow-hidden mb-5">
              <div className="flex items-center justify-between px-4 py-3 bg-[#6C63FF]/8">
                <div className="flex items-center gap-2">
                  <Crown className="w-4 h-4 text-[#6C63FF]" />
                  <span className="text-sm font-bold text-foreground">{activePlan.name}</span>
                  {activePlan.badge && (
                    <span
                      className="text-[9px] font-bold px-2 py-0.5 rounded-full text-white"
                      style={{ background: activePlan.badgeColor }}
                    >
                      {activePlan.id === "annual" ? "47% OFF" : "Melhor custo"}
                    </span>
                  )}
                </div>
              </div>
              <div className="px-4 py-3 space-y-2 border-t border-border">
                {activePlan.originalPrice && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Preco normal</span>
                    <span className="text-muted-foreground line-through">{activePlan.originalPrice}</span>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-foreground">Total</span>
                  <div className="text-right">
                    <p className="text-base font-bold text-[#6C63FF]">
                      {activePlan.id === "annual" ? "R$ 94,90/ano" : activePlan.price}
                    </p>
                    <p className="text-[10px] text-muted-foreground">{activePlan.description}</p>
                  </div>
                </div>
              </div>
              <div className="px-4 py-2.5 bg-[#43D787]/8 border-t border-[#43D787]/20 flex items-center gap-2">
                <Shield className="w-3.5 h-3.5 text-[#43D787] flex-shrink-0" />
                <p className="text-[10px] text-[#43D787] font-semibold">
                  Garantia de 7 dias — reembolso total se nao gostar
                </p>
              </div>
            </div>

            {/* Whats included */}
            <div className="mb-5">
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2.5">
                O que voce vai desbloquear
              </p>
              <div className="grid grid-cols-2 gap-2">
                {activePlan.features.map((f, i) => (
                  <div key={i} className="flex items-center gap-2 bg-muted/50 rounded-xl px-3 py-2.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#6C63FF] flex-shrink-0" />
                    <span className="text-[11px] font-medium text-foreground leading-tight">{f}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Payment method */}
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2.5">
              Forma de pagamento
            </p>
            <div className="space-y-2 mb-5">
              {PAY_METHODS.map((m) => {
                const isSelected = payMethod === m.id
                return (
                  <button
                    key={m.id}
                    onClick={() => setPayMethod(m.id)}
                    className={`w-full flex items-center gap-3 rounded-2xl p-3.5 border-2 text-left transition-all active:scale-98 ${
                      isSelected
                        ? "border-[#6C63FF] bg-[#6C63FF]/8"
                        : "border-border bg-muted/40"
                    }`}
                  >
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                      isSelected ? "bg-[#6C63FF]/20" : "bg-muted"
                    }`}>
                      <m.Icon className={`w-4.5 h-4.5 ${isSelected ? "text-[#6C63FF]" : "text-muted-foreground"}`} />
                    </div>
                    <div className="flex-1">
                      <p className={`text-sm font-semibold ${isSelected ? "text-foreground" : "text-foreground"}`}>
                        {m.label}
                      </p>
                      <p className="text-[10px] text-muted-foreground">{m.subtitle}</p>
                    </div>
                    <div className={`w-4.5 h-4.5 rounded-full border-2 flex-shrink-0 flex items-center justify-center transition-all ${
                      isSelected ? "border-[#6C63FF] bg-[#6C63FF]" : "border-border"
                    }`}>
                      {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                    </div>
                  </button>
                )
              })}
            </div>

            {/* Card form */}
            {payMethod === "card" && (
              <div className="space-y-3 mb-5 animate-slide-in">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Numero do cartao"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(formatCard(e.target.value))}
                    className="w-full h-12 pl-4 pr-11 rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:border-primary placeholder:text-muted-foreground"
                  />
                  <CreditCard className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-muted-foreground" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Validade MM/AA"
                    value={cardExpiry}
                    onChange={(e) => setCardExpiry(formatExpiry(e.target.value))}
                    className="w-full h-12 px-4 rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:border-primary placeholder:text-muted-foreground"
                  />
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="CVV"
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, "").slice(0, 4))}
                      className="w-full h-12 pl-4 pr-10 rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:border-primary placeholder:text-muted-foreground"
                    />
                    <Lock className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  </div>
                </div>
                <input
                  type="text"
                  placeholder="Nome no cartao"
                  value={cardName}
                  onChange={(e) => setCardName(e.target.value.toUpperCase())}
                  className="w-full h-12 px-4 rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:border-primary placeholder:text-muted-foreground"
                />
              </div>
            )}

            {/* PIX info */}
            {payMethod === "pix" && (
              <div className="mb-5 rounded-2xl bg-[#43D787]/10 border border-[#43D787]/25 p-4 text-center animate-slide-in">
                <QrCode className="w-10 h-10 text-[#43D787] mx-auto mb-2" />
                <p className="text-sm font-bold text-foreground mb-1">Pagamento por PIX</p>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Ao confirmar, voce recebera o QR Code e a chave PIX para finalizar o pagamento. Aprovacao imediata.
                </p>
              </div>
            )}

            {/* Boleto info */}
            {payMethod === "boleto" && (
              <div className="mb-5 rounded-2xl bg-muted/60 border border-border p-4 text-center animate-slide-in">
                <FileText className="w-10 h-10 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm font-bold text-foreground mb-1">Pagamento por Boleto</p>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Ao confirmar, o boleto sera gerado com vencimento em 3 dias uteis. O acesso e liberado apos confirmacao do pagamento.
                </p>
              </div>
            )}

            {/* Security strip */}
            <div className="flex items-center justify-center gap-4 mb-5">
              {["SSL 256-bit", "PCI DSS", "Dados criptografados"].map((badge) => (
                <div key={badge} className="flex items-center gap-1">
                  <Shield className="w-3 h-3 text-[#43D787]" />
                  <span className="text-[10px] text-muted-foreground">{badge}</span>
                </div>
              ))}
            </div>

            {/* Pay CTA */}
            <button
              onClick={handleSubscribe}
              disabled={processing || !canPay}
              className="w-full h-14 rounded-2xl text-white font-bold text-base flex items-center justify-center gap-2.5 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100"
              style={{
                background: "linear-gradient(135deg, #6C63FF 0%, #9C8DFF 100%)",
                boxShadow: canPay ? "0 8px 32px rgba(108,99,255,0.4)" : "none",
              }}
            >
              {processing ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Processando pagamento...
                </>
              ) : (
                <>
                  <Lock className="w-4.5 h-4.5" />
                  Confirmar e ativar Premium
                </>
              )}
            </button>
            <p className="text-center text-[10px] text-muted-foreground mt-2.5 leading-relaxed">
              Ao confirmar voce concorda com os{" "}
              <span className="text-primary font-semibold">Termos de Servico</span> e{" "}
              <span className="text-primary font-semibold">Politica de Privacidade</span>.
            </p>
          </div>
        )}

        {/* ================================================================
            STEP: SUCCESS
        ================================================================ */}
        {step === "success" && (
          <div className="flex-1 flex flex-col items-center justify-center px-5 py-8 text-center overflow-y-auto">
            {/* Crown with confetti dots */}
            <div className="relative mb-6">
              <div
                className="w-24 h-24 rounded-3xl flex items-center justify-center shadow-2xl animate-bounce-in"
                style={{ background: "linear-gradient(135deg, #6C63FF, #9C8DFF)" }}
              >
                <Crown className="w-12 h-12 text-white" />
              </div>
              {[
                { bg: "#6C63FF", top: "-10%", left: "50%" },
                { bg: "#FF6584", top: "10%",  left: "-15%" },
                { bg: "#43D787", top: "60%",  left: "-18%" },
                { bg: "#FFB347", top: "105%", left: "10%" },
                { bg: "#4FC3F7", top: "105%", left: "70%" },
                { bg: "#CE93D8", top: "60%",  left: "110%" },
                { bg: "#FF6584", top: "10%",  left: "110%" },
              ].map((dot, i) => (
                <div
                  key={i}
                  className="absolute w-3 h-3 rounded-full"
                  style={{
                    background: dot.bg,
                    top: dot.top,
                    left: dot.left,
                    animation: `confetti-fall ${0.8 + i * 0.12}s ease-out forwards`,
                  }}
                />
              ))}
            </div>

            <div className="inline-flex items-center gap-1.5 bg-[#43D787]/15 rounded-full px-3.5 py-1 mb-3">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#43D787]" />
              <span className="text-xs font-bold text-[#43D787]">Pagamento confirmado</span>
            </div>

            <h2 className="text-2xl font-bold text-foreground mb-2">
              Bem-vindo ao Premium!
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed mb-1">
              Seu plano{" "}
              <strong className="text-foreground">{activePlan.name}</strong>{" "}
              foi ativado com sucesso.
            </p>
            <p className="text-xs font-semibold text-[#43D787] mb-6">
              {getExpiryLabel(premiumState)}
            </p>

            {/* Unlocked features list */}
            <div className="w-full space-y-2 mb-7">
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider text-left mb-3">
                Recursos desbloqueados
              </p>
              {activePlan.features.map((f, i) => (
                <div
                  key={i}
                  className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 transition-all ${
                    i < successCount
                      ? "bg-[#6C63FF]/10 border border-[#6C63FF]/20"
                      : "bg-muted/40 opacity-40"
                  }`}
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <CheckCircle2
                    className={`w-4 h-4 flex-shrink-0 transition-colors ${
                      i < successCount ? "text-[#6C63FF]" : "text-muted-foreground"
                    }`}
                  />
                  <span className="text-xs font-semibold text-foreground">{f}</span>
                </div>
              ))}
            </div>

            {/* Share / continue */}
            <div className="w-full space-y-3">
              <button
                onClick={onClose}
                className="w-full h-14 rounded-2xl text-white font-bold text-base flex items-center justify-center gap-2 active:scale-95 transition-all"
                style={{
                  background: "linear-gradient(135deg, #6C63FF 0%, #9C8DFF 100%)",
                  boxShadow: "0 8px 32px rgba(108,99,255,0.4)",
                }}
              >
                <Zap className="w-5 h-5" />
                Comecar a usar o Premium
              </button>
              <button
                onClick={onClose}
                className="w-full h-11 rounded-2xl border border-border text-sm font-semibold text-muted-foreground active:scale-95 transition-all"
              >
                Compartilhar conquista
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

/* ---- Plan card sub-component ---- */
function PlanCard({
  plan,
  selected,
  onSelect,
}: {
  plan: Plan
  selected: boolean
  onSelect: () => void
}) {
  return (
    <button
      onClick={onSelect}
      className={`w-full rounded-2xl border-2 p-4 text-left transition-all active:scale-98 relative overflow-hidden ${
        plan.highlight
          ? selected
            ? "border-[#6C63FF] bg-[#6C63FF]/10"
            : "border-[#6C63FF]/50 bg-[#6C63FF]/5"
          : selected
          ? "border-primary/60 bg-primary/6"
          : "border-border bg-muted/40"
      }`}
    >
      {/* Badge */}
      {plan.badge && (
        <div
          className="absolute top-0 right-0 text-[10px] font-bold text-white px-3 py-1 rounded-bl-xl rounded-tr-xl"
          style={{ background: plan.badgeColor }}
        >
          {plan.id === "annual" ? "47% OFF" : plan.id === "lifetime" ? "Melhor custo" : plan.badge}
        </div>
      )}

      <div className="flex items-start gap-3">
        {/* Radio */}
        <div
          className={`w-5 h-5 rounded-full border-2 flex-shrink-0 mt-0.5 flex items-center justify-center transition-all ${
            selected ? "border-[#6C63FF] bg-[#6C63FF]" : "border-border"
          }`}
        >
          {selected && <div className="w-2 h-2 rounded-full bg-white" />}
        </div>

        <div className="flex-1 pr-2">
          <div className="flex items-baseline justify-between flex-wrap gap-1">
            <p className="text-sm font-bold text-foreground">{plan.name}</p>
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-bold text-[#6C63FF]">{plan.price}</span>
              <span className="text-[10px] text-muted-foreground">{plan.priceNote}</span>
            </div>
          </div>

          {plan.originalPrice && (
            <p className="text-[10px] text-muted-foreground mt-0.5">
              De <span className="line-through">{plan.originalPrice}</span>{" "}
              <span className="text-[#43D787] font-semibold">por R$ 94,90/ano</span>
            </p>
          )}

          {plan.id === "lifetime" && (
            <div className="flex items-center gap-1 mt-0.5">
              <Infinity className="w-3 h-3 text-[#6C63FF]" />
              <span className="text-[10px] text-[#6C63FF] font-semibold">Acesso para sempre</span>
            </div>
          )}

          {plan.id === "monthly" && (
            <p className="text-[10px] text-muted-foreground mt-0.5">Ideal para experimentar</p>
          )}

          <p className="text-[10px] text-muted-foreground mt-0.5">{plan.description}</p>

          {/* Expanded features */}
          {selected && (
            <div className="mt-3 space-y-1.5 animate-slide-in">
              {plan.features.map((f, i) => (
                <div key={i} className="flex items-center gap-2">
                  <Check className="w-3 h-3 text-[#43D787] flex-shrink-0" strokeWidth={2.5} />
                  <span className="text-[11px] text-foreground">{f}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Highlight glow */}
      {plan.highlight && (
        <div
          className="absolute bottom-0 left-0 right-0 h-0.5"
          style={{ background: "linear-gradient(90deg, transparent, #6C63FF, transparent)" }}
        />
      )}
    </button>
  )
}
