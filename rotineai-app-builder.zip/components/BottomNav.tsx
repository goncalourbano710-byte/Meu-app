"use client"

import { Home, CalendarDays, Plus, BarChart2, Settings, Crown } from "lucide-react"
import { PremiumState, isPremium } from "@/lib/premium"

export type Screen = "dashboard" | "week" | "add" | "stats" | "settings"

interface Props {
  active: Screen
  onChange: (screen: Screen) => void
  premiumState?: PremiumState
  onOpenPremium?: () => void
}

const TABS: { id: Screen; icon: typeof Home; label: string }[] = [
  { id: "dashboard", icon: Home,         label: "Hoje" },
  { id: "week",      icon: CalendarDays, label: "Semana" },
  { id: "add",       icon: Plus,         label: "Adicionar" },
  { id: "stats",     icon: BarChart2,    label: "Stats" },
  { id: "settings",  icon: Settings,     label: "Config" },
]

export default function BottomNav({ active, onChange, premiumState, onOpenPremium }: Props) {
  const userIsPremium = premiumState ? isPremium(premiumState) : false

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border safe-area-inset-bottom max-w-md mx-auto">
      <div className="flex items-end justify-around px-2 pt-2 pb-5">
        {TABS.map((tab) => {
          const isActive = active === tab.id
          const isAdd = tab.id === "add"

          return (
            <button
              key={tab.id}
              onClick={() => onChange(tab.id)}
              className={`flex flex-col items-center gap-1 transition-all active:scale-90 ${
                isAdd ? "-mt-5" : ""
              }`}
            >
              {isAdd ? (
                <div className="w-14 h-14 rounded-2xl gradient-primary flex items-center justify-center shadow-lg shadow-purple-500/40">
                  <Plus className="w-7 h-7 text-white" strokeWidth={2.5} />
                </div>
              ) : (
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                    isActive ? "bg-primary/15" : "bg-transparent"
                  }`}
                >
                  <tab.icon
                    className={`w-5 h-5 transition-colors ${
                      isActive ? "text-primary" : "text-muted-foreground"
                    }`}
                    strokeWidth={isActive ? 2.5 : 1.5}
                  />
                </div>
              )}
              {!isAdd && (
                <span
                  className={`text-[10px] font-medium transition-colors ${
                    isActive ? "text-primary" : "text-muted-foreground"
                  }`}
                >
                  {tab.label}
                </span>
              )}
            </button>
          )
        })}
      </div>

      {/* Floating Premium button — only visible for free users */}
      {!userIsPremium && onOpenPremium && (
        <button
          onClick={onOpenPremium}
          className="absolute -top-5 left-1/2 -translate-x-1/2 flex items-center gap-1.5 rounded-full px-4 py-1.5 text-white text-[11px] font-bold shadow-lg active:scale-95 transition-all"
          style={{
            background: "linear-gradient(135deg, #6C63FF 0%, #FF6584 100%)",
            boxShadow: "0 4px 20px rgba(108,99,255,0.45)",
            marginLeft: "80px",
          }}
        >
          <Crown className="w-3.5 h-3.5" />
          Assinar Premium
        </button>
      )}

      {/* Active premium badge — shows plan */}
      {userIsPremium && (
        <div
          className="absolute -top-5 left-1/2 -translate-x-1/2 flex items-center gap-1.5 rounded-full px-3.5 py-1.5"
          style={{
            background: "linear-gradient(135deg, #6C63FF, #9C8DFF)",
            marginLeft: "80px",
          }}
        >
          <Crown className="w-3 h-3 text-white" />
          <span className="text-[10px] font-bold text-white">PRO Ativo</span>
        </div>
      )}
    </nav>
  )
}
